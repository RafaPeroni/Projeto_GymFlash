<?php
    $host = 'localhost';
    $dbname = 'gymflash';
    $username = 'root';
    $password = '';
?>